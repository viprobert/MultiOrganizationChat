import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { loginApi } from '../api/auth';

const AuthContext = createContext(null);

export const useAuth = () => {
  return useContext(AuthContext);
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      const storedUser = sessionStorage.getItem('user');
      return storedUser ? JSON.parse(storedUser) : null;
    } catch (error) {
      console.error("Failed to parse user from session storage:", error);
      return null;
    }
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const login = useCallback(async (username, password) => {
    setLoading(true);
    setError(null);
    try {
      const response = await loginApi(username, password);
      if (response && response.userId && response.token) {
        const userData = {
          userId: response.userId,
          userName: response.userName,
          orgId: response.orgId,
          orgName: response.orgName,
          roleName: response.roleName,
          isOnline: response.isOnline,
          teamId: response.teamId,
          token: response.token
        };
        setUser(userData);
        sessionStorage.setItem('user', JSON.stringify(userData));
        return { success: true };
      } else {
        setError('Login failed: Invalid credentials or unexpected response.');
        return { success: false, message: 'Invalid credentials or unexpected response.' };
      }
    } catch (err) {
      console.error('Login error:', err);
      const errorMessage = err.response?.data?.message || err.message || 'An unexpected error occurred during login.';
      setError(errorMessage);
      return { success: false, message: errorMessage };
    } finally {
      setLoading(false);
    }
  }, []);

  // Logout function
  const logout = useCallback(() => {
    setUser(null);
    sessionStorage.removeItem('user'); 
    // In a real app, you might also call a backend logout API here
  }, []);

  // Value provided by the context
  const contextValue = {
    user,
    isAuthenticated: !!user, 
    loading,
    error,
    login,
    logout,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};
