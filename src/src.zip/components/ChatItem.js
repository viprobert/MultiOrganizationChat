import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTag, faCommentDots } from '@fortawesome/free-solid-svg-icons';

const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'N/A';
    const date = new Date(timestamp);
    const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    };
    return new Intl.DateTimeFormat('en-US', options).format(date);
};

const ChatItem = ({ chat, isSelected, onSelect, allAvailableTags }) => {
    const tagName = chat.TagId ? allAvailableTags.find(tag => tag.id === chat.TagId)?.name : null;

    return (
        <li
            className={`chat-item ${isSelected ? 'selected' : ''}`} 
            onClick={() => onSelect(chat)}
        >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <img
                    src={chat.pictureUrl || `https://placehold.co/48x48/cccccc/333333?text=${chat.displayname?.charAt(0) || '?'}`}
                    alt={chat.displayname || 'User'}
                    style={{ width: '3rem', height: '3rem', borderRadius: '50%', objectFit: 'cover', flexShrink: 0, border: '2px solid #66b3ff' }}
                />
                <div style={{ flexGrow: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h3 style={{ fontSize: '1rem', fontWeight: '600', color: '#333', maxWidth: '75%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {chat.displayname}
                        </h3>
                        {chat.unreadCount > 0 && (
                            <span style={{ backgroundColor: '#ff4444', color: 'white', fontSize: '0.75rem', fontWeight: 'bold', padding: '0.125rem 0.5rem', borderRadius: '9999px' }}>
                                {chat.unreadCount}
                            </span>
                        )}
                    </div>
                    <p style={{ fontSize: '0.875rem', color: '#555', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginTop: '0.25rem' }}>
                        {chat.chatMessage?.content || 'No messages'}
                    </p>
                    <p style={{ fontSize: '0.75rem', color: '#777', marginTop: '0.25rem' }}>
                        {formatTimestamp(chat.latestMsgTime)}
                    </p>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.25rem', marginTop: '0.25rem' }}>
                         {/* Display platform */}
                         <span style={{ backgroundColor: '#e0f2ff', color: '#007bff', fontSize: '0.75rem', padding: '0.125rem 0.5rem', borderRadius: '9999px' }}>
                            {chat.platfrom}
                        </span>
                        {/* Display single TagId (if available) */}
                        {tagName && (
                            <span style={{ backgroundColor: '#e6e0ff', color: '#6610f2', fontSize: '0.75rem', padding: '0.125rem 0.5rem', borderRadius: '9999px' }}>
                                <FontAwesomeIcon icon={faTag} style={{ marginRight: '0.25rem' }} />
                                {tagName}
                            </span>
                        )}
                        {/* Display chat status */}
                        {chat.ChatStatus && (
                            <span style={{
                                fontSize: '0.75rem',
                                padding: '0.125rem 0.5rem',
                                borderRadius: '9999px',
                                fontWeight: '600',
                                backgroundColor: chat.ChatStatus === 'Active' || chat.ChatStatus === 'InProgress' ? '#d4edda' :
                                                 chat.ChatStatus === 'Pending' ? '#fff3cd' :
                                                 chat.ChatStatus === 'Assigned' ? '#e0f2ff' :
                                                 chat.ChatStatus === 'Closed' ? '#f8d7da' : '#eee',
                                color: chat.ChatStatus === 'Active' || chat.ChatStatus === 'InProgress' ? '#155724' :
                                       chat.ChatStatus === 'Pending' ? '#856404' :
                                       chat.ChatStatus === 'Assigned' ? '#004085' :
                                       chat.ChatStatus === 'Closed' ? '#721c24' : '#333'
                            }}>
                                {chat.ChatStatus}
                            </span>
                        )}
                    </div>
                </div>
            </div>
        </li>
    );
};

export default ChatItem;
