import React, { useRef, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSpinner } from '@fortawesome/free-solid-svg-icons';

const formatMessageTimestamp = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const options = {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
        month: 'short',
        day: 'numeric'
    };
    return new Intl.DateTimeFormat('en-US', options).format(date);
};

const ChatMessageArea = ({ chatHistory, loading, error, currentAgentId }) => {
    const messagesEndRef = useRef(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [chatHistory]);

    if (loading) {
        return (
            <div style={{ flex: '1', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem', backgroundColor: '#f9f9f9' }}>
                <FontAwesomeIcon icon={faSpinner} spin style={{ fontSize: '2rem', color: '#007bff' }} />
                <p style={{ marginLeft: '0.75rem', color: '#555' }}>Loading messages...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div style={{ flex: '1', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '1rem', backgroundColor: '#ffe0e0', color: '#cc0000' }}>
                <p>Error loading messages: {error}</p>
            </div>
        );
    }

    if (!chatHistory || !chatHistory.chatMessages || chatHistory.chatMessages.length === 0) {
        return (
            <div style={{ flex: '1', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '1rem', backgroundColor: '#f9f9f9' }}>
                <p style={{ color: '#777', fontSize: '1.125rem' }}>No messages in this chat yet.</p>
                <p style={{ fontSize: '0.875rem', color: '#777', marginTop: '0.5rem' }}>Start the conversation below!</p>
            </div>
        );
    }

    const sortedMessages = [...chatHistory.chatMessages].sort((a, b) =>
        new Date(a.timeStamp) - new Date(b.timeStamp)
    );

    return (
        <div className="custom-scrollbar" style={{ flex: '1', overflowY: 'auto', padding: '1rem', backgroundColor: '#f9f9f9' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {sortedMessages.map((message) => {
                    const isAgentMessage = message.senderType === 'Agent' && message.senderUserId === currentAgentId;
                    const isOtherAgentMessage = message.senderType === 'Agent' && message.senderUserId !== currentAgentId;

                    let bubbleStyle = {
                        maxWidth: '70%',
                        padding: '0.75rem',
                        borderRadius: '0.75rem',
                        marginBottom: '0.5rem',
                        wordWrap: 'break-word',
                        whiteSpace: 'pre-wrap',
                        boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
                    };
                    let flexAlign = 'flex-start';

                    if (isAgentMessage) {
                        bubbleStyle = {
                            ...bubbleStyle,
                            backgroundColor: '#007bff',
                            color: 'white',
                            marginLeft: 'auto',
                            borderBottomRightRadius: 0
                        };
                        flexAlign = 'flex-end';
                    } else if (isOtherAgentMessage) {
                        bubbleStyle = {
                            ...bubbleStyle,
                            backgroundColor: '#d0e0f0', 
                            color: '#333',
                            marginRight: 'auto',
                            borderBottomLeftRadius: 0
                        };
                        flexAlign = 'flex-start';
                    } else { 
                        bubbleStyle = {
                            ...bubbleStyle,
                            backgroundColor: '#e2e2e2',
                            color: '#333',
                            marginRight: 'auto',
                            borderBottomLeftRadius: 0
                        };
                        flexAlign = 'flex-start';
                    }


                    return (
                        <div
                            key={message.id}
                            style={{ display: 'flex', justifyContent: flexAlign }}
                        >
                            <div style={bubbleStyle}>
                                {message.messageType === 'image' && message.content ? (
                                    <img src={message.content} alt="Sent" style={{ maxWidth: '100%', borderRadius: '0.5rem' }} />
                                ) : message.messageType === 'audio' && message.content ? (
                                    <audio controls src={message.content} style={{ width: '100%' }}></audio>
                                ) : (
                                    <p style={{ margin: 0, fontSize: '0.9rem' }}>{message.content}</p>
                                )}
                                <span style={{ display: 'block', textAlign: 'right', fontSize: '0.65rem', opacity: '0.8', marginTop: '0.25rem' }}>
                                    {formatMessageTimestamp(message.timeStamp)}
                                </span>
                            </div>
                        </div>
                    );
                })}
                <div ref={messagesEndRef} />
            </div>
        </div>
    );
};

export default ChatMessageArea;
