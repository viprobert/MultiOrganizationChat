import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUserCircle, faSpinner } from '@fortawesome/free-solid-svg-icons';

const AuthPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const { login, loading, error } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const result = await login(username, password);
    if (!result.success) {
      console.error("Login failed:", result.message);
    }
  };

  return (
    <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        minHeight: '100vh',
        background: 'linear-gradient(to bottom right, #e0f2ff, #c3dafe)', 
        padding: '1rem',
        fontFamily: 'sans-serif'
    }}>
      <div style={{
          backgroundColor: '#ffffff',
          borderRadius: '1rem',
          boxShadow: '0 10px 15px rgba(0,0,0,0.1)',
          padding: '2rem',
          maxWidth: '400px',
          width: '100%'
      }}>
        <h2 style={{
            fontSize: '1.875rem',
            fontWeight: 'bold',
            textAlign: 'center',
            color: '#333',
            marginBottom: '2rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
        }}>
          <FontAwesomeIcon icon={faUserCircle} style={{ marginRight: '0.5rem', color: '#007bff' }} />
          Agent Login
        </h2>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <label htmlFor="username" style={{ display: 'block', fontSize: '0.875rem', fontWeight: '500', color: '#555', marginBottom: '0.25rem' }}>
              Username
            </label>
            <input
              type="text"
              id="username"
              name="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              style={{
                  display: 'block',
                  width: 'calc(100% - 2rem)', /* account for padding */
                  padding: '0.75rem 1rem',
                  border: '1px solid #ccc',
                  borderRadius: '0.5rem',
                  boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
                  transition: 'border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out'
              }}
              placeholder="Enter your username"
              required
            />
          </div>
          <div>
            <label htmlFor="password" style={{ display: 'block', fontSize: '0.875rem', fontWeight: '500', color: '#555', marginBottom: '0.25rem' }}>
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{
                  display: 'block',
                  width: 'calc(100% - 2rem)',
                  padding: '0.75rem 1rem',
                  border: '1px solid #ccc',
                  borderRadius: '0.5rem',
                  boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
                  transition: 'border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out'
              }}
              placeholder="Enter your password"
              required
            />
          </div>

          {error && (
            <div style={{
                backgroundColor: '#ffe0e0',
                border: '1px solid #ffb3b3',
                color: '#cc0000',
                padding: '0.75rem 1rem',
                borderRadius: '0.5rem',
                fontSize: '0.875rem'
            }} role="alert">
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            style={{
                width: '100%',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                padding: '0.75rem 1rem',
                border: 'none',
                borderRadius: '0.5rem',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                color: 'white',
                backgroundColor: loading ? '#a0c0e0' : '#007bff', /* Lighter blue when loading */
                fontSize: '1.125rem',
                fontWeight: '500',
                cursor: loading ? 'not-allowed' : 'pointer',
                transition: 'background-color 0.2s ease, transform 0.2s ease',
                transform: loading ? 'scale(1.0)' : 'scale(1.0)'
            }}
            onMouseOver={e => e.currentTarget.style.backgroundColor = loading ? '#a0c0e0' : '#0056b3'}
            onMouseOut={e => e.currentTarget.style.backgroundColor = loading ? '#a0c0e0' : '#007bff'}
            disabled={loading}
          >
            {loading ? (
              <FontAwesomeIcon icon={faSpinner} spin style={{ marginRight: '0.75rem' }} />
            ) : 'Log In'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AuthPage;
