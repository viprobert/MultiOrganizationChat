import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { changeAgentStatusApi } from '../api/auth';
import { getAllChannelsApi } from '../api/channels';
import { getAssignedChatsByAgentStatusApi, getFilteredChatsApi, seenMessageApi, getChatMessageHistoryApi, assignChatToAgentApi, changeChatStatusApi, sendMessageApi } from '../api/chats';
import { getChatsByTagApi, getAllTagsApi, setUserTaggingApi, removeTagFromUserApi } from '../api/tags';
import { getTeamsAndAgentsApi } from '../api/teams';
import { setUserNoteApi } from '../api/notes';
import { useSignalR } from '../hooks/useSignalR';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPowerOff, faBars, faTimes, faUserCircle, faTag, faCommentDots, faArrowRightArrowLeft, faNoteSticky, faPaperPlane, faEllipsisV, faSpinner, faChevronDown, faChevronUp } from '@fortawesome/free-solid-svg-icons';
import {
  FaFacebookMessenger,
  FaLine,
  FaTelegramPlane,
  FaWhatsapp,
} from 'react-icons/fa';

import ChatItem from '../components/ChatItem';
import ChatMessageArea from '../components/ChatMessageArea';
import MessageInput from '../components/MessageInput';

const platformIcons = {
  LINE: <FaLine size={20} style={{ color: '#00B900' }} />,
  TELEGRAM: <FaTelegramPlane size={20} style={{ color: '#0088CC' }} />,
  WhatsApp: <FaWhatsapp size={20} style={{ color: '#25D366' }} />,
  Messenger: <FaFacebookMessenger size={20} style={{ color: '#0078FF' }} />,
};

const DashboardPage = () => {
    const { user, logout } = useAuth();
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [agentOnlineStatus, setAgentOnlineStatus] = useState(user?.isOnline ?? false);
    const [loadingDashboard, setLoadingDashboard] = useState(true);
    const [dashboardError, setDashboardError] = useState(null);
    const [channels, setChannels] = useState([]);
    const [tagsWithCounts, setTagsWithCounts] = useState([]);
    const [agentAssignedChatsCounts, setAgentAssignedChatsCounts] = useState({ all: 0, unread: 0 });
    const [chatList, setChatList] = useState([]);
    const [selectedChat, setSelectedChat] = useState(null);
    const [currentChatHistory, setCurrentChatHistory] = useState(null); 
    const [chatListLoading, setChatListLoading] = useState(false);
    const [chatListError, setChatListError] = useState(null);
    const [selectedChannelId, setSelectedChannelId] = useState(null); 
    const [selectedChatStatusFilter, setSelectedChatStatusFilter] = useState('All'); // 'All', 'Unread', 'Pending', 'Assigned', 'InProgress', 'Closed'
    const [selectedTagIdFilter, setSelectedTagIdFilter] = useState(null); 
    const [searchTerm, setSearchTerm] = useState(''); 
    const [allAvailableTags, setAllAvailableTags] = useState([]);
    const [teamsAndAgents, setTeamsAndAgents] = useState([]);
    const [isActionPanelLoading, setIsActionPanelLoading] = useState(false);
    const [actionPanelError, setActionPanelError] = useState(null);
    const [currentChatNote, setCurrentChatNote] = useState('');
    const [currentChatTags, setCurrentChatTags] = useState([]);
    const [isActionPanelVisible, setIsActionPanelVisible] = useState(false);
    const [isChannelsSectionVisible, setIsChannelsSectionVisible] = useState(false);


    const fetchChatList = useCallback(async () => {
        if (!user?.orgId || !user?.token) {
            console.warn("Missing user orgId or token for fetching chat list.");
            return;
        }

        setChatListLoading(true);
        setChatListError(null);
        try {
            const params = {
                orgId: user.orgId,
                configId: selectedChannelId,
                tagId: selectedTagIdFilter,
                sortBy: 'latestMsgTime',
                sortOrder: 'desc',
                page: 1,
                pageSize: 20
            };

            if (selectedChatStatusFilter === 'All' || selectedChatStatusFilter === 'Unread') {
                params.agentId = user.userId;
            } else {
                params.status = selectedChatStatusFilter;
                params.agentId = null;
            }

            if (searchTerm) {
                params.searchTerm = searchTerm;
            }

            const chats = await getFilteredChatsApi(params, user.token);

            let finalFilteredChats = chats;
            if (selectedChatStatusFilter === 'Unread') {
                finalFilteredChats = chats.filter(chat => chat.unreadCount > 0);
            }

            setChatList(finalFilteredChats);
            if (selectedChat && !finalFilteredChats.some(chat => chat.chatId === selectedChat.chatId)) {
                setSelectedChat(null);
                setCurrentChatHistory(null);
            }

        } catch (err) {
            console.error("Error fetching chat list:", err);
            setChatListError("Failed to load chat list. " + (err.message || "Please try again."));
        } finally {
            setChatListLoading(false);
        }
    }, [user, selectedChannelId, selectedChatStatusFilter, selectedTagIdFilter, searchTerm]);

    const handleReceiveMessage = useCallback((message) => {
        setCurrentChatHistory(prevHistory => {
            if (prevHistory && prevHistory.chatId === message.chatId) {
                if (!prevHistory.chatMessages?.some(msg => msg.id === message.id)) {
                    return {
                        ...prevHistory,
                        chatMessages: [...(prevHistory.chatMessages || []), message]
                    };
                }
            }
            return prevHistory;
        });

        // Update the chat list to reflect new message and potentially unread status
        setChatList(prevChats => {
            const chatToUpdateIndex = prevChats.findIndex(chat => chat.chatId === message.chatId);
            if (chatToUpdateIndex > -1) {
                const updatedChats = [...prevChats];
                const chatToUpdate = { ...updatedChats[chatToUpdateIndex] };

                // Update latest message and time
                chatToUpdate.chatMessage = message;
                chatToUpdate.latestMsgTime = message.timeStamp;

                // Increment unread count if the message is from a customer and chat is not selected
                // Or if it's from another agent and the chat is not selected
                const isCustomerMessage = message.senderType === 'Customer';
                const isOtherAgentMessage = message.senderType === 'Agent' && message.senderUserId !== user?.userId;

                if ((isCustomerMessage || isOtherAgentMessage) && selectedChat?.chatId !== message.chatId) {
                    chatToUpdate.unreadCount = (chatToUpdate.unreadCount || 0) + 1;
                    // Also update global unread count
                    setAgentAssignedChatsCounts(prevCounts => ({
                        ...prevCounts,
                        unread: (prevCounts.unread || 0) + 1
                    }));
                }

                // Move chat to top of the list
                updatedChats.splice(chatToUpdateIndex, 1); // Remove from current position
                updatedChats.unshift(chatToUpdate); // Add to the beginning

                return updatedChats;
            } else {
                // If chat is not in the current list (e.g., new chat), re-fetch the chat list
                // This might be heavy for many new chats, consider a specific API for new chat notifications.
                // For now, re-fetching will ensure it appears.
                fetchChatList();
                return prevChats;
            }
        });

    }, [selectedChat, user?.userId, fetchChatList]);

    const handleChatUpdated = useCallback((chatUpdate) => {
        console.log('Chat updated via SignalR:', chatUpdate);

        setChatList(prevChats => prevChats.map(chat => {
            if (chat.chatId === chatUpdate.chatId) {
                return {
                    ...chat,
                    ...chatUpdate
                };
            }
            return chat;
        }));

        setCurrentChatHistory(prevHistory => {
            if (prevHistory && prevHistory.chatId === chatUpdate.chatId) {
                return {
                    ...prevHistory,
                    note: chatUpdate.note ?? prevHistory.note,
                    tagId: chatUpdate.tagId ?? prevHistory.tagId,
                    ChatStatus: chatUpdate.status ?? prevHistory.ChatStatus,
                    assignedAgentId: chatUpdate.assignedAgentId ?? prevHistory.assignedAgentId 
                };
            }
            return prevHistory;
        });

        const updateAgentCounts = async () => {
            if (user?.userId && user?.token && user?.orgId) {
                const assignedChats = await getAssignedChatsByAgentStatusApi(user.userId, user.orgId, user.token);
                const allAssignedCount = assignedChats.length;
                const unreadAssignedCount = assignedChats.filter(chat => chat.unreadCount > 0).length;
                setAgentAssignedChatsCounts({ all: allAssignedCount, unread: unreadAssignedCount });
            }
        };
        updateAgentCounts();
        fetchChatList();
    }, [user, fetchChatList]);

    const { isConnected: isSignalRConnected, error: signalRError } = useSignalR(
        user?.userId,
        user?.token,
        handleReceiveMessage,
        handleChatUpdated
    );

    useEffect(() => {
        const fetchDashboardData = async () => {
            if (!user?.orgId || !user?.token || !user?.userId) {
                setDashboardError("User organization, ID, or token not found. Please re-login.");
                setLoadingDashboard(false);
                return;
            }

            try {
                setLoadingDashboard(true);
                setDashboardError(null);

                const [channelsData, assignedChats, tagsData, allTags, teamsAgentsData] = await Promise.all([
                    getAllChannelsApi(user.orgId, user.token),
                    getAssignedChatsByAgentStatusApi(user.userId, user.orgId, user.token),
                    getChatsByTagApi(user.orgId, user.token),
                    getAllTagsApi(user.orgId, user.token),
                    getTeamsAndAgentsApi(user.orgId, user.token)
                ]);

                setChannels(channelsData);

                const allAssignedCount = assignedChats.length;
                const unreadAssignedCount = assignedChats.filter(chat => chat.unreadCount > 0).length;
                setAgentAssignedChatsCounts({ all: allAssignedCount, unread: unreadAssignedCount });

                setTagsWithCounts(tagsData);
                setAllAvailableTags(allTags);
                setTeamsAndAgents(teamsAgentsData);

            } catch (err) {
                console.error("Error fetching dashboard initial data:", err);
                setDashboardError("Failed to load dashboard data. " + (err.message || "Please try again."));
            } finally {
                setLoadingDashboard(false);
            }
        };

        fetchDashboardData();
    }, [user, user?.orgId, user?.userId, user?.token]);

    useEffect(() => {
        if (!loadingDashboard && !dashboardError) {
            fetchChatList();
        }
    }, [loadingDashboard, dashboardError, selectedChannelId, selectedChatStatusFilter, selectedTagIdFilter, searchTerm, fetchChatList]);


    const handleAgentStatusToggle = async () => {
        if (!user?.userId || !user?.token) return;
        setIsActionPanelLoading(true);
        setActionPanelError(null);
        try {
            const newStatus = !agentOnlineStatus;
            await changeAgentStatusApi(user.userId, newStatus, user.token);
            setAgentOnlineStatus(newStatus);
        } catch (err) {
            console.error("Failed to change agent status:", err);
            setActionPanelError("Failed to change status: " + (err.message || "Unknown error."));
        } finally {
            setIsActionPanelLoading(false);
        }
    };

    const handleChatSelect = useCallback(async (chat) => {
        setSelectedChat(chat);
        setIsActionPanelVisible(false);

        try {
            setActionPanelError(null);
            setIsActionPanelLoading(true);

            const history = await getChatMessageHistoryApi(chat.chatId, user.token);
            setCurrentChatHistory(history);

            const noteContent = history?.note || '';
            setCurrentChatNote(noteContent);
            setCurrentChatTags(history?.tagId ? [history.tagId] : []);

            if (chat.unreadCount > 0) {
                await seenMessageApi(chat.chatId, user.userId, history.chatMessages?.[0]?.id || null, user.token);

                setChatList(prevChats => prevChats.map(c =>
                    c.chatId === chat.chatId ? { ...c, unreadCount: 0 } : c
                ));
                setAgentAssignedChatsCounts(prevCounts => ({
                    ...prevCounts,
                    unread: Math.max(0, prevCounts.unread - chat.unreadCount)
                }));
            }
        } catch (err) {
            console.error("Error fetching chat history or marking seen:", err);
            setActionPanelError("Failed to load chat conversation: " + (err.message || "Unknown error."));
            setCurrentChatHistory(null);
        } finally {
            setIsActionPanelLoading(false);
        }
    }, [user, user?.userId, user?.token]);

    const handleSetNote = async () => {
        if (!selectedChat?.chatId || !user?.token || currentChatNote === currentChatHistory?.note) return;
        setIsActionPanelLoading(true);
        setActionPanelError(null);
        try {
            await setUserNoteApi(selectedChat.chatId, currentChatNote, user.token);
            setCurrentChatHistory(prev => ({ ...prev, note: currentChatNote }));
            alert('Note set successfully!');
        } catch (err) {
            console.error("Error setting note:", err);
            setActionPanelError("Failed to set note: " + (err.message || "Unknown error."));
        } finally {
            setIsActionPanelLoading(false);
        }
    };

    const handleSetTag = async (tagId) => {
        if (!selectedChat?.chatId || !user?.token || !tagId || tagId === currentChatTags?.[0]) return;
        setIsActionPanelLoading(true);
        setActionPanelError(null);
        try {
            await setUserTaggingApi(selectedChat.chatId, tagId, user.token);
            setCurrentChatTags([tagId]);
            setChatList(prevChats => prevChats.map(c =>
                c.chatId === selectedChat.chatId ? { ...c, TagId: tagId } : c
            ));
            const updatedHistory = await getChatMessageHistoryApi(selectedChat.chatId, user.token);
            setCurrentChatHistory(updatedHistory);
            alert('Tag set successfully!');
            fetchChatList();
        } catch (err) {
            console.error("Error setting tag:", err);
            setActionPanelError("Failed to set tag: " + (err.message || "Unknown error."));
        } finally {
            setIsActionPanelLoading(false);
        }
    };

    const handleRemoveTag = async () => {
        if (!selectedChat?.chatId || !user?.token || !currentChatTags?.length) return;
        setIsActionPanelLoading(true);
        setActionPanelError(null);
        try {
            await removeTagFromUserApi(selectedChat.chatId, currentChatTags[0], user.token);
            setCurrentChatTags([]);
            setChatList(prevChats => prevChats.map(c =>
                c.chatId === selectedChat.chatId ? { ...c, TagId: null } : c
            ));
            const updatedHistory = await getChatMessageHistoryApi(selectedChat.chatId, user.token);
            setCurrentChatHistory(updatedHistory);
            alert('Tag removed successfully!');
            fetchChatList();
        } catch (err) {
            console.error("Error removing tag:", err);
            setActionPanelError("Failed to remove tag: " + (err.message || "Unknown error."));
        } finally {
            setIsActionPanelLoading(false);
        }
    };

    const handleAssignAgent = async (agentId) => {
        if (!selectedChat?.chatId || !user?.token || !agentId || selectedChat.assignedAgentId === agentId) return;
        setIsActionPanelLoading(true);
        setActionPanelError(null);
        try {
            await assignChatToAgentApi(selectedChat.chatId, agentId, user.token);
            setChatList(prevChats => prevChats.map(c =>
                c.chatId === selectedChat.chatId ? { ...c, assignedAgentId: agentId } : c
            ));
            setSelectedChat(prev => ({ ...prev, assignedAgentId: agentId }));
            alert('Chat assigned successfully!');
            fetchChatList();
        } catch (err) {
            console.error("Error assigning chat:", err);
            setActionPanelError("Failed to assign chat: " + (err.message || "Unknown error."));
        } finally {
            setIsActionPanelLoading(false);
        }
    };

    const handleChangeChatStatus = async (status) => {
        if (!selectedChat?.chatId || !user?.token || !status || status === selectedChat.ChatStatus) return;
        setIsActionPanelLoading(true);
        setActionPanelError(null);
        try {
            await changeChatStatusApi(selectedChat.chatId, status, user.token);
            setChatList(prevChats => prevChats.map(c =>
                c.chatId === selectedChat.chatId ? { ...c, ChatStatus: status } : c
            ));
            setSelectedChat(prev => ({ ...prev, ChatStatus: status }));
            alert('Chat status changed successfully!');
            fetchChatList();
        } catch (err) {
            console.error("Error changing chat status:", err);
            setActionPanelError("Failed to change chat status: " + (err.message || "Unknown error."));
        } finally {
            setIsActionPanelLoading(false);
        }
    };

    const handleSendMessage = async (content, messageType = 'text') => {
        if (!selectedChat?.chatId || !user?.token || (!content && messageType === 'text')) return;

        const messageData = {
            channelId: selectedChat.channelConfig,
            chatId: selectedChat.chatId,
            externalSenderId: user.userId,
            platform: selectedChat.platfrom,
            type: messageType,
            text: content,
            audioDuration: messageType === 'audio' ? 0 : 0
        };

        try {
            setCurrentChatHistory(prevHistory => {
                const newChatMessage = {
                    id: `temp-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
                    chatId: selectedChat.chatId,
                    senderType: 'Agent',
                    senderUserId: user.userId,
                    externalSenderId: user.userId,
                    content: content,
                    messageType: messageType,
                    timeStamp: new Date().toISOString(),
                    externalMessageId: null
                };
                return {
                    ...prevHistory,
                    chatMessages: [...(prevHistory?.chatMessages || []), newChatMessage]
                };
            });

            await sendMessageApi(messageData, user.token);
            fetchChatList();
        } catch (err) {
            console.error("Error sending message:", err);
            alert("Failed to send message: " + (err.message || "Unknown error."));
            setCurrentChatHistory(prevHistory => {
                if (prevHistory && prevHistory.chatMessages) {
                    return {
                        ...prevHistory,
                        chatMessages: prevHistory.chatMessages.filter(msg => !msg.id.startsWith('temp-'))
                    };
                }
                return prevHistory;
            });
        }
    };

    const handleChannelFilterChange = (channelId) => {
        setSelectedChannelId(channelId === 'All' ? null : channelId);
        setSelectedTagIdFilter(null);
        setSelectedChatStatusFilter('All');
        setSelectedChat(null);
        setSearchTerm('');
    };

    const handleStatusFilterChange = (status) => {
        setSelectedChatStatusFilter(status);
        setSelectedChannelId(null);
        setSelectedTagIdFilter(null);
        setSelectedChat(null);
        setSearchTerm('');
    };

    const handleTagFilterChange = (tagId) => {
        setSelectedTagIdFilter(tagId === 'All' ? null : tagId);
        setSelectedChannelId(null);
        setSelectedChatStatusFilter('All');
        setSelectedChat(null);
        setSearchTerm('');
    };


    const statusColor = agentOnlineStatus ? 'green' : 'red'; 
    const statusText = agentOnlineStatus ? 'Online' : 'Offline';

    return (
        <div className="container-full-height">
            {/* Mobile Sidebar Toggle */}
            <button
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                style={{
                    position: 'fixed', top: '1rem', left: '1rem', zIndex: 50,
                    padding: '0.5rem', borderRadius: '50%', backgroundColor: '#007bff', color: 'white',
                    border: 'none', boxShadow: '0 2px 5px rgba(0,0,0,0.2)', cursor: 'pointer',
                    display: window.innerWidth <= 768 ? 'block' : 'none'
                }}
                aria-label="Toggle sidebar"
            >
                <FontAwesomeIcon icon={isSidebarOpen ? faTimes : faBars} size="lg" />
            </button>

            {/* Left Sidebar */}
            <aside
                className={`sidebar ${isSidebarOpen ? 'open' : 'closed'}`}
                style={{
                    transform: isSidebarOpen ? 'translateX(0)' : (window.innerWidth <= 768 ? 'translateX(-100%)' : 'translateX(0)'),
                    position: window.innerWidth <= 768 ? 'fixed' : 'relative',
                    transition: 'transform 0.3s ease-in-out',
                    width: '250px',
                    backgroundColor: '#ffffff',
                    boxShadow: '2px 0 5px rgba(0,0,0,0.1)',
                    display: 'flex',
                    flexDirection: 'column',
                    zIndex: 40
                }}
            >
                {/* Header/Agent Info */}
                <div style={{ padding: '1.5rem', background: 'linear-gradient(to right, #007bff, #6610f2)', color: 'white', borderRadius: '0 1rem 0 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <FontAwesomeIcon icon={faUserCircle} style={{ fontSize: '2rem', marginRight: '0.75rem' }} />
                        <div>
                            <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', margin: 0 }}>{user?.userName || 'Agent'}</h2>
                            <p style={{ fontSize: '0.875rem', opacity: 0.9, margin: 0 }}>{user?.orgName || 'Organization'}</p>
                        </div>
                    </div>
                    {/* Agent Status Toggle */}
                    <div style={{ position: 'relative' }}>
                        <button
                            onClick={handleAgentStatusToggle}
                            style={{
                                display: 'flex', alignItems: 'center', padding: '0.25rem 0.75rem',
                                borderRadius: '9999px', fontSize: '0.75rem', fontWeight: '600', boxShadow: '0 1px 2px rgba(0,0,0,0.1)',
                                backgroundColor: agentOnlineStatus ? '#28a745' : '#dc3545', color: 'white', border: 'none',
                                cursor: isActionPanelLoading ? 'not-allowed' : 'pointer',
                                transition: 'background-color 0.2s ease'
                            }}
                            onMouseOver={e => { if (!e.currentTarget.disabled) e.currentTarget.style.backgroundColor = agentOnlineStatus ? '#218838' : '#c82333'; }}
                            onMouseOut={e => { if (!e.currentTarget.disabled) e.currentTarget.style.backgroundColor = agentOnlineStatus ? '#28a745' : '#dc3545'; }}
                            title={`Click to go ${agentOnlineStatus ? 'Offline' : 'Online'}`}
                            disabled={isActionPanelLoading}
                        >
                            <span style={{ width: '0.625rem', height: '0.625rem', borderRadius: '50%', marginRight: '0.5rem', backgroundColor: statusColor }}></span>
                            {isActionPanelLoading ? 'Updating...' : statusText}
                        </button>
                    </div>
                </div>

                {/* Filters Section */}
                <div className="custom-scrollbar" style={{ flexGrow: 1, padding: '1rem', overflowY: 'auto' }}>
                    {/* SignalR Connection Status */}
                    {signalRError && (
                        <div style={{ backgroundColor: '#ffe0e0', border: '1px solid #ffb3b3', color: '#cc0000', padding: '0.75rem', borderRadius: '0.5rem', fontSize: '0.875rem', marginBottom: '1rem' }}>
                            <FontAwesomeIcon icon={faSpinner} spin style={{ marginRight: '0.5rem' }} /> {signalRError}
                        </div>
                    )}
                    {isSignalRConnected && !signalRError && (
                        <div style={{ backgroundColor: '#d4edda', border: '1px solid #c3e6cb', color: '#155724', padding: '0.75rem', borderRadius: '0.5rem', fontSize: '0.875rem', marginBottom: '1rem' }}>
                            <FontAwesomeIcon icon={faCommentDots} style={{ marginRight: '0.5rem' }} /> Real-time updates active.
                        </div>
                    )}

                    {/* Channel/Group List */}
                    <div style={{ marginBottom: '1.5rem', backgroundColor: '#f9f9f9', padding: '0.5rem', borderRadius: '1rem', boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #eee' }}>
                        <h3 style={{ fontSize: '1.125rem', fontWeight: 'bold', marginBottom: '0.75rem', color: '#333', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <span style={{ display: 'flex', alignItems: 'center' }}>
                                <FontAwesomeIcon icon={faCommentDots} style={{ marginRight: '0.5rem', color: '#007bff' }} />
                                Channels
                            </span>
                            <button
                                onClick={() => setIsChannelsSectionVisible(!isChannelsSectionVisible)}
                                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#555', fontSize: '1rem' }}
                                title={isChannelsSectionVisible ? "Hide Channels" : "Show Channels"}
                            >
                                <FontAwesomeIcon icon={isChannelsSectionVisible ? faChevronUp : faChevronDown} />
                            </button>
                        </h3>
                        {isChannelsSectionVisible && (
                            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                                <li>
                                    <button
                                        onClick={() => handleChannelFilterChange('All')}
                                        style={{
                                            width: '100%', textAlign: 'left', padding: '0.5rem 0.75rem', borderRadius: '0.5rem',
                                            transition: 'background-color 0.2s ease', border: 'none', cursor: 'pointer',
                                            backgroundColor: selectedChannelId === null ? '#e0f2ff' : 'transparent',
                                            color: selectedChannelId === null ? '#007bff' : '#555',
                                            fontWeight: selectedChannelId === null ? 'bold' : 'normal'
                                        }}
                                        onMouseOver={e => { if (selectedChannelId !== null) e.currentTarget.style.backgroundColor = '#f0f0f0'; }}
                                        onMouseOut={e => { if (selectedChannelId !== null) e.currentTarget.style.backgroundColor = 'transparent'; }}
                                    >
                                        All Channels
                                    </button>
                                </li>
                                {channels.map(channel => (
                                    <li key={channel.id}>
                                        <button
                                            onClick={() => handleChannelFilterChange(channel.id)}
                                            style={{
                                                width: '100%', textAlign: 'left', padding: '0.5rem 0.75rem', borderRadius: '0.5rem',
                                                transition: 'background-color 0.2s ease', border: 'none', cursor: 'pointer',
                                                backgroundColor: selectedChannelId === channel.id ? '#e0f2ff' : 'transparent',
                                                color: selectedChannelId === channel.id ? '#007bff' : '#555',
                                                fontWeight: selectedChannelId === channel.id ? 'bold' : 'normal',
                                                display: 'flex', alignItems: 'center'
                                            }}
                                            onMouseOver={e => { if (selectedChannelId !== channel.id) e.currentTarget.style.backgroundColor = '#f0f0f0'; }}
                                            onMouseOut={e => { if (selectedChannelId !== channel.id) e.currentTarget.style.backgroundColor = 'transparent'; }}
                                        >
                                            <span style={{ marginRight: '0.5rem' }}>
                                                {platformIcons[channel.platform] || <FontAwesomeIcon icon={faPaperPlane} style={{color: '#777'}}/>}
                                            </span>
                                            {channel.name} ({channel.platform})
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>

                    {/* Status and Counts */}
                    <div style={{ marginBottom: '1.5rem', backgroundColor: '#f9f9f9', padding: '0.5rem', borderRadius: '1rem', boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #eee' }}>
                        <h3 style={{ fontSize: '1.125rem', fontWeight: 'bold', marginBottom: '0.75rem', color: '#333', display: 'flex', alignItems: 'center' }}>
                             <FontAwesomeIcon icon={faCommentDots} style={{ marginRight: '0.5rem', color: '#007bff' }} />
                            My Chats
                        </h3>
                        <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <li>
                                <button
                                    onClick={() => handleStatusFilterChange('All')}
                                    style={{
                                        width: '100%', textAlign: 'left', padding: '0.5rem 0.75rem', borderRadius: '0.5rem',
                                        transition: 'background-color 0.2s ease', border: 'none', cursor: 'pointer',
                                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                        backgroundColor: selectedChatStatusFilter === 'All' ? '#e0f2ff' : 'transparent',
                                        color: selectedChatStatusFilter === 'All' ? '#007bff' : '#555',
                                        fontWeight: selectedChatStatusFilter === 'All' ? 'bold' : 'normal'
                                    }}
                                    onMouseOver={e => { if (selectedChatStatusFilter !== 'All') e.currentTarget.style.backgroundColor = '#f0f0f0'; }}
                                    onMouseOut={e => { if (selectedChatStatusFilter !== 'All') e.currentTarget.style.backgroundColor = 'transparent'; }}
                                >
                                    <span>All Assigned</span>
                                    <span style={{ backgroundColor: '#cce5ff', color: '#004085', padding: '0.125rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: '600' }}>
                                        {agentAssignedChatsCounts.all}
                                    </span>
                                </button>
                            </li>
                            <li>
                                <button
                                    onClick={() => handleStatusFilterChange('Unread')}
                                    style={{
                                        width: '100%', textAlign: 'left', padding: '0.5rem 0.75rem', borderRadius: '0.5rem',
                                        transition: 'background-color 0.2s ease', border: 'none', cursor: 'pointer',
                                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                        backgroundColor: selectedChatStatusFilter === 'Unread' ? '#e0f2ff' : 'transparent',
                                        color: selectedChatStatusFilter === 'Unread' ? '#007bff' : '#555',
                                        fontWeight: selectedChatStatusFilter === 'Unread' ? 'bold' : 'normal'
                                    }}
                                    onMouseOver={e => { if (selectedChatStatusFilter !== 'Unread') e.currentTarget.style.backgroundColor = '#f0f0f0'; }}
                                    onMouseOut={e => { if (selectedChatStatusFilter !== 'Unread') e.currentTarget.style.backgroundColor = 'transparent'; }}
                                >
                                    <span>Unread</span>
                                    <span style={{ backgroundColor: '#f8d7da', color: '#721c24', padding: '0.125rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: '600' }}>
                                        {agentAssignedChatsCounts.unread}
                                    </span>
                                </button>
                            </li>
                            {['Pending', 'Assigned', 'InProgress', 'Closed'].map(status => (
                                <li key={status}>
                                    <button
                                        onClick={() => handleStatusFilterChange(status)}
                                        style={{
                                            width: '100%', textAlign: 'left', padding: '0.5rem 0.75rem', borderRadius: '0.5rem',
                                            transition: 'background-color 0.2s ease', border: 'none', cursor: 'pointer',
                                            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                            backgroundColor: selectedChatStatusFilter === status ? '#e0f2ff' : 'transparent',
                                            color: selectedChatStatusFilter === status ? '#007bff' : '#555',
                                            fontWeight: selectedChatStatusFilter === status ? 'bold' : 'normal'
                                        }}
                                        onMouseOver={e => { if (selectedChatStatusFilter !== status) e.currentTarget.style.backgroundColor = '#f0f0f0'; }}
                                        onMouseOut={e => { if (selectedChatStatusFilter !== status) e.currentTarget.style.backgroundColor = 'transparent'; }}
                                    >
                                        <span>{status}</span>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Tag List */}
                    <div style={{ marginBottom: '1.5rem', backgroundColor: '#f9f9f9', padding: '0.5rem', borderRadius: '1rem', boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #eee' }}>
                        <h3 style={{ fontSize: '1.125rem', fontWeight: 'bold', marginBottom: '0.75rem', color: '#333', display: 'flex', alignItems: 'center' }}>
                            <FontAwesomeIcon icon={faTag} style={{ marginRight: '0.5rem', color: '#007bff' }} />
                            Tags
                        </h3>
                        <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                            <li>
                                <button
                                    onClick={() => handleTagFilterChange('All')}
                                    style={{
                                        width: '100%', textAlign: 'left', padding: '0.5rem 0.75rem', borderRadius: '0.5rem',
                                        transition: 'background-color 0.2s ease', border: 'none', cursor: 'pointer',
                                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                        backgroundColor: selectedTagIdFilter === null ? '#e0f2ff' : 'transparent',
                                        color: selectedTagIdFilter === null ? '#007bff' : '#555',
                                        fontWeight: selectedTagIdFilter === null ? 'bold' : 'normal'
                                    }}
                                    onMouseOver={e => { if (selectedTagIdFilter !== null) e.currentTarget.style.backgroundColor = '#f0f0f0'; }}
                                    onMouseOut={e => { if (selectedTagIdFilter !== null) e.currentTarget.style.backgroundColor = 'transparent'; }}
                                >
                                    <span>All Tags</span>
                                </button>
                            </li>
                            {tagsWithCounts.map(tag => (
                                <li key={tag.id}>
                                    <button
                                        onClick={() => handleTagFilterChange(tag.id)}
                                        style={{
                                            width: '100%', textAlign: 'left', padding: '0.5rem 0.75rem', borderRadius: '0.5rem',
                                            transition: 'background-color 0.2s ease', border: 'none', cursor: 'pointer',
                                            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                            backgroundColor: selectedTagIdFilter === tag.id ? '#e0f2ff' : 'transparent',
                                            color: selectedTagIdFilter === tag.id ? '#007bff' : '#555',
                                            fontWeight: selectedTagIdFilter === tag.id ? 'bold' : 'normal'
                                        }}
                                        onMouseOver={e => { if (selectedTagIdFilter !== tag.id) e.currentTarget.style.backgroundColor = '#f0f0f0'; }}
                                        onMouseOut={e => { if (selectedTagIdFilter !== tag.id) e.currentTarget.style.backgroundColor = 'transparent'; }}
                                    >
                                        <span>{tag.name}</span>
                                        <span style={{ backgroundColor: '#e2e2e2', color: '#555', padding: '0.125rem 0.5rem', borderRadius: '9999px', fontSize: '0.75rem', fontWeight: '600' }}>
                                            {tag.chatList ? tag.chatList.length : 0}
                                        </span>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>

                {/* Logout Button */}
                <div style={{ padding: '1rem', borderTop: '1px solid #eee' }}>
                    <button
                        onClick={logout}
                        style={{
                            width: '100%', padding: '0.5rem 1rem', borderRadius: '0.5rem',
                            backgroundColor: '#dc3545', color: 'white', fontWeight: '600',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            boxShadow: '0 1px 2px rgba(0,0,0,0.1)', border: 'none', cursor: 'pointer',
                            transition: 'background-color 0.2s ease'
                        }}
                        onMouseOver={e => e.currentTarget.style.backgroundColor = '#c82333'}
                        onMouseOut={e => e.currentTarget.style.backgroundColor = '#dc3545'}
                    >
                        <FontAwesomeIcon icon={faPowerOff} style={{ marginRight: '0.5rem' }} />
                        Logout
                    </button>
                </div>
            </aside>

            {/* Main Content Area */}
            <main className="main-content" style={{ borderRadius: '1.5rem 0 0 1.5rem', boxShadow: '-2px 0 10px rgba(0,0,0,0.1)' }}>
                {/* Chat List Column */}
                <section className="chat-list-section">
                    <header className="header-panel" style={{ backgroundColor: '#f9f9f9' }}>
                        <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', color: '#333', margin: 0 }}>
                            Chat Inbox
                            <span style={{ marginLeft: '0.5rem', backgroundColor: '#e0f2ff', color: '#007bff', fontSize: '0.875rem', padding: '0.25rem 0.75rem', borderRadius: '9999px' }}>{chatList.length}</span>
                        </h2>
                        {/* Search bar */}
                        <input
                            type="text"
                            placeholder="Search chats..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') {
                                    fetchChatList();
                                }
                            }}
                            style={{
                                marginTop: '0.75rem', width: 'calc(100% - 1rem)', padding: '0.5rem',
                                border: '1px solid #ccc', borderRadius: '0.5rem',
                                transition: 'border-color 0.15s ease-in-out'
                            }}
                        />
                    </header>
                    <div className="custom-scrollbar" style={{ flex: 1, overflowY: 'auto', padding: '1rem' }}>
                        {chatListLoading ? (
                            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                                <FontAwesomeIcon icon={faSpinner} spin style={{ fontSize: '1.5rem', color: '#007bff' }} />
                            </div>
                        ) : chatListError ? (
                            <div style={{ textAlign: 'center', color: '#cc0000' }}>Error: {chatListError}</div>
                        ) : chatList.length === 0 ? (
                            <div style={{ textAlign: 'center', color: '#777', padding: '2rem' }}>No chats found with current filters.</div>
                        ) : (
                            <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                                {chatList.map(chat => (
                                    <ChatItem
                                        key={chat.chatId}
                                        chat={chat}
                                        isSelected={selectedChat?.chatId === chat.chatId}
                                        onSelect={handleChatSelect}
                                        allAvailableTags={allAvailableTags}
                                        platformIcons={platformIcons}
                                    />
                                ))}
                            </ul>
                        )}
                    </div>
                </section>

                {/* Chat Conversation & Actions Column */}
                <section className="chat-conversation-section">
                    {selectedChat ? (
                        <>
                        {/* Chat Actions Panel (Hideable) */}
                            {isActionPanelVisible && (
                                <div className="action-panel">
                                    {/* Set Note */}
                                    <div className="action-card">
                                        <label htmlFor="chat-note">
                                            <FontAwesomeIcon icon={faNoteSticky} style={{ marginRight: '0.25rem' }} /> Note:
                                        </label>
                                        <textarea
                                            id="chat-note"
                                            value={currentChatNote}
                                            onChange={(e) => setCurrentChatNote(e.target.value)}
                                            placeholder="Add a note for this chat..."
                                            rows="2"
                                            disabled={isActionPanelLoading}
                                        ></textarea>
                                        <button onClick={handleSetNote} disabled={isActionPanelLoading || currentChatNote === currentChatHistory?.note} className="blue">
                                            {isActionPanelLoading ? 'Saving...' : 'Set Note'}
                                        </button>
                                    </div>

                                    {/* Assign Agent/Team */}
                                    <div className="action-card">
                                        <label htmlFor="assign-agent">
                                            <FontAwesomeIcon icon={faArrowRightArrowLeft} style={{ marginRight: '0.25rem' }} /> Transfer Chat:
                                        </label>
                                        <select
                                            id="assign-agent"
                                            value={selectedChat.assignedAgentId || ''}
                                            onChange={(e) => handleAssignAgent(e.target.value)}
                                            disabled={isActionPanelLoading}
                                        >
                                            <option value="">Select Agent or Team</option>
                                            {teamsAndAgents.map(team => (
                                                <optgroup key={team.id} label={`Team: ${team.name}`}>
                                                    {team.usersList.map(agent => (
                                                        <option key={agent.userId} value={agent.userId}>
                                                            {agent.userName} {agent.isOnline ? '(Online)' : '(Offline)'}
                                                        </option>
                                                    ))}
                                                </optgroup>
                                            ))}
                                        </select>
                                        <button onClick={() => handleAssignAgent(selectedChat.assignedAgentId)} disabled={isActionPanelLoading || !selectedChat.assignedAgentId} className="indigo">
                                            {isActionPanelLoading ? 'Transferring...' : 'Transfer'}
                                        </button>
                                    </div>

                                    {/* Set/Remove Tag */}
                                    <div className="action-card">
                                        <label htmlFor="set-tag">
                                            <FontAwesomeIcon icon={faTag} style={{ marginRight: '0.25rem' }} /> Tags:
                                        </label>
                                        <select
                                            id="set-tag"
                                            value={currentChatTags?.[0] || ''}
                                            onChange={(e) => handleSetTag(e.target.value)}
                                            disabled={isActionPanelLoading}
                                        >
                                            <option value="">Select a Tag</option>
                                            {allAvailableTags.map(tag => (
                                                <option key={tag.id} value={tag.id}>
                                                    {tag.name}
                                                </option>
                                            ))}
                                        </select>
                                        <button onClick={() => handleSetTag(currentChatTags?.[0] || null)} disabled={isActionPanelLoading || !currentChatTags?.[0]} className="green">
                                            {isActionPanelLoading ? 'Applying...' : 'Apply Tag'}
                                        </button>
                                        {currentChatTags?.length > 0 && (
                                            <button onClick={handleRemoveTag} disabled={isActionPanelLoading} className="red" style={{ marginTop: '0.5rem' }}>
                                                {isActionPanelLoading ? 'Removing...' : 'Remove Current Tag'}
                                            </button>
                                        )}
                                    </div>

                                    {/* Change Status */}
                                    <div className="action-card">
                                        <label htmlFor="change-status">
                                            <FontAwesomeIcon icon={faCommentDots} style={{ marginRight: '0.25rem' }} /> Change Status:
                                        </label>
                                        <select
                                            id="change-status"
                                            value={selectedChat?.chatStatus || ''}
                                            onChange={(e) => handleChangeChatStatus(e.target.value)}
                                            disabled={isActionPanelLoading}
                                        >
                                            <option value="">Select Status</option>
                                            {['Pending', 'Assigned', 'InProgress', 'Closed'].map(statusOption => (
                                                <option key={statusOption} value={statusOption}>
                                                    {statusOption}
                                                </option>
                                            ))}
                                        </select>
                                        <button onClick={() => handleChangeChatStatus(selectedChat?.chatStatus)} disabled={isActionPanelLoading || !selectedChat?.chatStatus} className="yellow">
                                            {isActionPanelLoading ? 'Updating...' : 'Set Status'}
                                        </button>
                                    </div>
                                    {actionPanelError && (
                                        <div style={{ gridColumn: 'span 4', backgroundColor: '#ffe0e0', border: '1px solid #ffb3b3', color: '#cc0000', padding: '0.75rem', borderRadius: '0.5rem', fontSize: '0.875rem' }} role="alert">
                                            <span>{actionPanelError}</span>
                                        </div>
                                    )}
                                </div>
                            )}

                            {/* Chat Header (Conversation View) */}
                            <header className="header-panel" style={{ backgroundColor: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                                    <img
                                        src={selectedChat.pictureUrl || `https://placehold.co/48x48/cccccc/333333?text=${selectedChat.displayname?.charAt(0) || '?'}`}
                                        alt={selectedChat.displayname || 'User'}
                                        style={{ width: '3rem', height: '3rem', borderRadius: '50%', objectFit: 'cover', border: '2px solid #007bff' }}
                                    />
                                    <div>
                                        <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', margin: 0 }}>{selectedChat.displayname}</h2>
                                        <p style={{ fontSize: '0.875rem', color: '#555', margin: 0 }}>
                                            Platform: {selectedChat.platfrom} | Status: {selectedChat.chatStatus}
                                        </p>
                                    </div>
                                </div>
                                {/* Toggle Action Panel Button */}
                                <button
                                    onClick={() => setIsActionPanelVisible(!isActionPanelVisible)}
                                    style={{ padding: '0.5rem', borderRadius: '50%', background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.25rem', color: '#555' }}
                                    onMouseOver={e => e.currentTarget.style.backgroundColor = '#f0f0f0'}
                                    onMouseOut={e => e.currentTarget.style.backgroundColor = 'transparent'}
                                    title={isActionPanelVisible ? "Hide Actions" : "Show Actions"}
                                >
                                    <FontAwesomeIcon icon={faEllipsisV} />
                                </button>
                            </header>

                            {/* Chat Message Area */}
                            <ChatMessageArea
                                chatHistory={currentChatHistory}
                                loading={isActionPanelLoading}
                                error={actionPanelError}
                                currentAgentId={user?.userId}
                                currentChatTags={currentChatTags}
                                selectedChatStatus={selectedChat?.ChatStatus}
                                allAvailableTags={allAvailableTags}
                                selectedChatPlatform={selectedChat?.platfrom}
                                platformIcons={platformIcons}
                            />

                            {/* Message Input Area */}
                            <MessageInput
                                onSendMessage={handleSendMessage}
                                isLoading={isActionPanelLoading}
                            />
                        </>
                    ) : (
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#777' }}>
                            <svg style={{ width: '5rem', height: '5rem', marginBottom: '1rem' }} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm-5-8a1 1 0 011-1h8a1 1 0 110 2H6a1 1 0 01-1-1z" clipRule="evenodd"></path></svg>
                            <p style={{ fontSize: '1.25rem', fontWeight: '600' }}>Select a chat to view conversation</p>
                            <p style={{ fontSize: '0.875rem', marginTop: '0.5rem' }}>Click on any chat from the left panel to begin.</p>
                        </div>
                    )}
                </section>
            </main>
        </div>
    );
};

export default DashboardPage;
