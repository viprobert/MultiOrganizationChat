import {API_BASE_URL as API_URL} from '../config/api';

const API_BASE_URL = API_URL;


export const loginApi = async (username, password) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Authentication`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'ngrok-skip-browser-warning': '69420',
      },
      body: JSON.stringify({ username, password }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.response;
  } catch (error) {
    console.error("Error during login API call:", error);
    throw error;
  }
};

export const changeAgentStatusApi = async (agentId, isOnline, token) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Authentication/ChangeStatus`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'ngrok-skip-browser-warning': '69420',
      },
      body: JSON.stringify({ agentId, isOnline }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    return { success: true };

  } catch (error) {
    console.error("Error changing agent status API call:", error);
    throw error;
  }
};
