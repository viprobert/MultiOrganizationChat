import {API_BASE_URL as API_URL} from '../config/api';

const API_BASE_URL = API_URL;

export const getTeamsAndAgentsApi = async (orgId, token) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Team/GetUsersByTeam?orgId=${orgId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`, 
        'Content-Type': 'application/json',
        'ngrok-skip-browser-warning': '69420',
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data; 
  } catch (error) {
    console.error("Error fetching teams and agents:", error);
    throw error;
  }
};
