import {API_BASE_URL as API_URL} from '../config/api';

const API_BASE_URL = API_URL;


export const getChatsByTagApi = async (orgId, token) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Tagging/GetChatsByTag?orgId=${orgId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'ngrok-skip-browser-warning': '69420',
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching chats by tag:", error);
    throw error;
  }
};


export const getAllTagsApi = async (orgId, token) => {
  try {
    const response = await fetch(`${API_BASE_URL}/Tagging`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        'ngrok-skip-browser-warning': '69420',
      },
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching all tags:", error);
    throw error;
  }
};


export const setUserTaggingApi = async (chatId, tagId, token) => {
  try {
    const response = await fetch(`${API_BASE_URL}/GroupMessages/SetUserTagging`, {
      method: 'POST', 
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'ngrok-skip-browser-warning': '69420',
      },
      body: JSON.stringify({ chatId, tagId }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    return { success: true }; 
  } catch (error) {
    console.error("Error setting user tagging:", error);
    throw error;
  }
};

export const removeTagFromUserApi = async (chatId, tagId, token) => {
  try {
    const response = await fetch(`${API_BASE_URL}/GroupMessages/RemoveTagFromUser`, {
      method: 'POST', 
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
        'ngrok-skip-browser-warning': '69420',
      },
      body: JSON.stringify({ chatId, tagId }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
    }

    return { success: true };
  } catch (error) {
    console.error("Error removing tag from user:", error);
    throw error;
  }
};
